/**
 * vim: et:ts=4:sw=4:sts=4
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPL-3.0-or-later)
 * Copyright 2025 Josh Y Oshiro
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
export const tokenColors={
	white:"#EAEAEA",
	black:"#121212",
	red:"#E12222",
	green:"#10C510",
	blue:"#4060F8",
	purple:"#910891",
	yellow:"#E1E112",
	orange:"#E86600",
	pink:"#FF69B4",
	brown:"#A0522D",
	gray:"#8E8E8E",
	cyan:"#00FFFF",
	magenta:"#FF00FF",
	lime:"#00FF00",
	teal:"#0090A0",
	maroon:"#C84070",
	navy:"#000090",
	olive:"#808000"
};

export const playerColors={
	0:tokenColors["red"],
	1:tokenColors["blue"]
}
/*
* win outcomes between two ai players will vary with different depths.
* {depth:1,speed:<100ms}
* {depth:2,speed:<100ms}
* {depth:3,speed:<100ms}
* {depth:4,speed:very fast}
* {depth:5,speed:fast}
* {depth:6,speed:moderate}
* {depth:7,speed:slow}
* {depth:8,speed:very slow}
*/
export const searchDepth=13; //Depth of the search to perform
export const minSafe=-10000000000000; //MiniMax values
export const maxSafe=10000000000000; //MiniMax values
export const evalPlayerScoreRatio=0.65; //Weight the score between p0/p1, this will affect positional play.
export const positionalIncrement=20;
export const depthDependantWeight=1.01;