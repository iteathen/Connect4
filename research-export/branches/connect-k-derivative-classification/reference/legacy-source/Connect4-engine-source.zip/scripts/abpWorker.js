//abpWorker.js
/**
 * vim: et:ts=4:sw=4:sts=4
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPL-3.0-or-later)
 * Copyright 2025 Josh Y Oshiro
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
import{
	minSafe,
	maxSafe,
	evalPlayerScoreRatio,
	depthDependantWeight
} from "./globalDefinitions.js";
import{
	virtualBoard
} from "./virtualBoard.js";
export const isModule = true;
const transpositionTable=new Map();
const moveOrderCache=new Map();
const maxTranspositionEntries=200000;

self.onmessage=(e)=>{
	try{
		const boardData=e.data.board;
		const vb=new virtualBoard(boardData.columns,boardData.rows);
		vb.nextTurn=0;
		const moves=boardData.moves||boardData.moveSequence||[];
		for(let moveIndex=0;moveIndex<moves.length;moveIndex++){
			const jsonObj=moves[moveIndex];
			const [col,row]=JSON.parse(jsonObj);
			const placed=vb._placeMove(col, moveIndex%2);
			if(placed===null) throw new Error(`Failed to reconstruct move ${jsonObj}`);
		}
		vb.nextTurn=vb.tokenCount%2;
		const player=vb.nextTurn;
		const maxDepth=e.data.depth;

		const moveOrderKey=`${vb.columns}`;
		let moveOrder=moveOrderCache.get(moveOrderKey);
		if(!moveOrder){
			moveOrder=[];
			const center=Math.floor(vb.columns/2);
			moveOrder.push(center);
			for(let offset=1;offset<vb.columns;offset++){
				const left=center-offset;
				const right=center+offset;
				if(left>=0) moveOrder.push(left);
				if(right<vb.columns) moveOrder.push(right);
			}
			moveOrderCache.set(moveOrderKey,moveOrder);
		}
		const center=Math.floor(vb.columns/2);
		function getDepthScale(depth){
			return Math.max(depth*depthDependantWeight,1);
		}
		function scoreForWinner(winner, depth){
			if(winner===-1) return 0;
			if(winner===player) return maxSafe/getDepthScale(depth);
			return minSafe/getDepthScale(depth);
		}
		function evaluatePosition(boardObject, depth){
			const p0s=boardObject.score(player);
			const p1s=(boardObject.score(1-player)*evalPlayerScoreRatio);
			return (p0s-p1s)/getDepthScale(depth);
		}
		function getLegalMoves(boardObject){
			const legalMoves=[];
			for(let orderIdx=0;orderIdx<moveOrder.length;orderIdx++){
				const column=moveOrder[orderIdx];
				if(boardObject.columnHeights[column] < boardObject.rows){
					legalMoves.push(column);
				}
			}
			return legalMoves;
		}
		function getTranspositionKey(boardObject){
			return `${boardObject.hash}:${boardObject.nextTurn}`;
		}
		function sortMoves(boardObject, moves, ttMove=null){
			if(moves.length<=1) return moves;
			const rankedMoves=moves.map((column, index)=>({
				column,
				order:index,
				score:(column===ttMove?1000:0)-Math.abs(center-column)
			}));
			rankedMoves.sort((left,right)=>{
				if(right.score!==left.score) return right.score-left.score;
				return left.order-right.order;
			});
			return rankedMoves.map(entry=>entry.column);
		}

		function minimaxAlphaBetaSearch(depthCounter,boardObject,alpha,beta){
			let bestMove=null;
			const winner=boardObject.checkWin();
			if(winner!==null){
				return [scoreForWinner(winner,depthCounter),null];
			}
			if(depthCounter>=maxDepth){
				return [evaluatePosition(boardObject,depthCounter),null];
			}
			const originalAlpha=alpha;
			const originalBeta=beta;
			const remainingDepth=maxDepth-depthCounter;
			const key=getTranspositionKey(boardObject);
			const cached=transpositionTable.get(key);
			if(cached&&cached.depth>=remainingDepth){
				bestMove=cached.bestMove;
				if(cached.flag==="exact") return [cached.score,bestMove];
				if(cached.flag==="lower") alpha=Math.max(alpha,cached.score);
				else if(cached.flag==="upper") beta=Math.min(beta,cached.score);
				if(alpha>=beta) return [cached.score,bestMove];
			}
			const currentPlayer=boardObject.nextTurn;
			let legalMoves=getLegalMoves(boardObject);
			if(legalMoves.length===0){
				return [evaluatePosition(boardObject,depthCounter),null];
			}
			let immediateWinMove=null;
			for(let idx=0;idx<legalMoves.length;idx++){
				const column=legalMoves[idx];
				if(boardObject.isWinningMove(column,currentPlayer)){
					immediateWinMove=column;
					break;
				}
			}
			if(immediateWinMove!==null){
				const value=scoreForWinner(currentPlayer,depthCounter+1);
				transpositionTable.set(key,{depth:remainingDepth,score:value,bestMove:immediateWinMove,flag:"exact"});
				return [value,immediateWinMove];
			}
			const opponentThreats=[];
			for(let idx=0;idx<legalMoves.length;idx++){
				const column=legalMoves[idx];
				if(boardObject.isWinningMove(column,1-currentPlayer)){
					opponentThreats.push(column);
				}
			}
			if(opponentThreats.length>1){
				const forcedLossScore=scoreForWinner(1-currentPlayer,depthCounter+1);
				transpositionTable.set(key,{depth:remainingDepth,score:forcedLossScore,bestMove:opponentThreats[0],flag:"exact"});
				return [forcedLossScore,opponentThreats[0]];
			}
			if(opponentThreats.length===1){
				legalMoves=[opponentThreats[0]];
			}else{
				legalMoves=sortMoves(boardObject,legalMoves,bestMove);
			}
			if(legalMoves.length===1){
				bestMove=legalMoves[0];
			}
			const isMax=currentPlayer===player;
			let value=isMax?minSafe/getDepthScale(depthCounter):maxSafe/getDepthScale(depthCounter);
			for(let idx=0;idx<legalMoves.length;idx++){
				const column=legalMoves[idx];
				const undoRecord=boardObject.applyMove(column);
				if(undoRecord===null) continue;
				const result=minimaxAlphaBetaSearch(depthCounter+1,boardObject,alpha,beta);
				boardObject.undoMove(undoRecord);
				const score=result[0];
				if(isMax){
					if(score>value){
						value=score;
						bestMove=column;
					}
					alpha=Math.max(alpha,value);
					if(alpha>=beta) break;
				}else{
					if(score<value){
						value=score;
						bestMove=column;
					}
					beta=Math.min(beta,value);
					if(beta<=alpha) break;
				}
			}
			let flag="exact";
			if(value<=originalAlpha) flag="upper";
			else if(value>=originalBeta) flag="lower";
			transpositionTable.set(key,{depth:remainingDepth,score:value,bestMove,flag});
			return[value,bestMove];
		}


		const [score,move]=minimaxAlphaBetaSearch(0,vb,minSafe,maxSafe);
		if(transpositionTable.size>maxTranspositionEntries){
			transpositionTable.clear();
		}
				
		if(move===null) console.log("minimaxAlphaBetaSearch returned a 'null' move from the worker!!!","Player: ",player,"Score: ",score,"Move: ",move);
		else console.log("Player: ",player,"Score: ",score,"Move: ",move, "Winner: ", vb.winner);
		//vb.displayBoard();
		
		self.postMessage({score,move});
	}
	catch(error){
        console.error("Error from worker:", error);
        self.postMessage({error:"Worker message: "+error.message});
	}
};
