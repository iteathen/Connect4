//classDefinitions.js
/**
 * vim: et:ts=4:sw=4:sts=4
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPL-3.0-or-later)
 * Copyright 2025 Josh Y Oshiro
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
import {
	playerColors,
	searchDepth,
	minSafe,
	maxSafe
} from "./globalDefinitions.js";
import {
	updateNodes,
	buildNodeTree,
	encodeCssSelector
} from "./utils.js";

export class MusicManager{
	constructor(audioContext,audioBuffersRef,musicVolume=0.5){
		if(!audioContext){
			throw new Error("AudioContext must be provided to MusicManager.");
		}
		this.audioCtx=audioContext;
		this.musicVolume=musicVolume;
		this.audioBuffers=audioBuffersRef;
		this.musicTrackNames=[];
		this.currentSourceNode=null;
		this.currentGainNode=null;
		this.nowPlayingIndex=0;
		this.queuedIndex=0;
		this.onMusicEndedHandler=this.onMusicEnded.bind(this);
	}
	setMusicTrackNames(names){
		this.musicTrackNames=names;
		if(this.musicTrackNames.length>0){
			this.nowPlayingIndex=0;
			this.queuedIndex=this.musicTrackNames.length>1?1:0;
		}else{
			console.warn("MusicManager: No music track names provided.");
		}
	}
	shuffle(){
		if(this.musicTrackNames.length===0){
			console.warn("MusicManager: No music to shuffle.");
			return;
		}
		this.stop();
		let rng=Math.floor(Math.random()*this.musicTrackNames.length);
		this.play(rng);
	}
	next(){
		if(this.musicTrackNames.length===0){
			console.warn("MusicManager: No next track.");
			return;
		}
		this.stop();
		this.play(this.queuedIndex);
	}
	stop(){
		if(this.currentSourceNode){
			try{
				this.currentSourceNode.stop();
				this.currentSourceNode.disconnect();
				if(this.currentGainNode){
					this.currentGainNode.disconnect();
				}
				this.currentSourceNode.onended=null;
			}catch(e){
				console.warn("Error stopping audio source:",e);
			}finally{
				this.currentSourceNode=null;
				this.currentGainNode=null;
			}
		}
	}
	play(index){
		if(this.musicTrackNames.length===0||index<0||index>=this.musicTrackNames.length){
			console.warn("MusicManager: Invalid index or no music tracks available.");
			return;
		}
		this.stop();
		const trackName=this.musicTrackNames[index];
		const audioBuffer=this.audioBuffers[trackName];
		if(!audioBuffer){
			console.error(`Music track '${trackName}' buffer not found. Make sure it was loaded.`);
			return;
		}
		const source=this.audioCtx.createBufferSource();
		source.buffer=audioBuffer;
		source.loop=false;
		const gainNode=this.audioCtx.createGain();
		gainNode.gain.value=this.musicVolume;
		source.connect(gainNode);
		gainNode.connect(this.audioCtx.destination);
		source.start(0);
		this.currentSourceNode=source;
		this.currentGainNode=gainNode;
		this.nowPlayingIndex=index;
		this.queueNext();
		source.onended=this.onMusicEndedHandler;
	}
	onMusicEnded(){
		if(!this.currentSourceNode) return;
		this.currentSourceNode=null;
		if(this.currentGainNode){
			this.currentGainNode.disconnect();
			this.currentGainNode=null;
		}
		this.next();
	}
	queueNext(){
		if(this.musicTrackNames.length===0)return;
		this.queuedIndex=(this.nowPlayingIndex+1)%this.musicTrackNames.length;
	}
	setVolume(volume){
		this.musicVolume=volume;
		if(this.currentGainNode){
			this.currentGainNode.gain.value=volume;
		}
	}
}
export class Board{
	constructor(columns,rows,myGameBoard=null,isVirtual=false){
		this.winner=null;
		this.winningLineCoordinates=null;
		this.isVirtual=isVirtual;
		this.gameBoardElement=myGameBoard;
		this.rows=rows;
		this.columns=columns;
		this.moveSequence=[];
		this.tokens=new Map();
		for(let c=0;c<columns;c++)
			for(let r=0;r<rows;r++)
				this.tokens.set(JSON.stringify([c,r]),null);
		this.baseWinningPositions=this.findWinningPositions();
		this.playerWinningPositions=[];
		this.playerWinningPositions[0]=structuredClone(this.baseWinningPositions);
		this.playerWinningPositions[1]=structuredClone(this.baseWinningPositions);
		//it is very important to be sure that no DOM elements are present in the Board object unless !this.isVirtual
		if(!this.isVirtual){
			buildNodeTree(this,this.gameBoardElement);
			this.gameBoardElement.getRootNode().documentElement.style.setProperty("--row-count", this.rows);
			this.gameBoardElement.getRootNode().documentElement.style.setProperty("--col-count", this.columns);
		}
		this.updateValueMap();
	}
	resetWinState() {
		this.winner = null;
		this.winningLineCoordinates = null;
	}
	undo(){
		if(this.moveSequence.length>0){
			this.tokens.set(this.moveSequence.pop()[0],null);
			if(!this.isVirtual) updateNodes(this);
			this.playerWinningPositions[0]=structuredClone(this.baseWinningPositions);
			this.playerWinningPositions[1]=structuredClone(this.baseWinningPositions);
			this.updateWinnablePositions();
			this.updateValueMap();
			this.resetWinState();
			return true;
		}
		return false;
	}
	addToken(column){
		if(column===null){
			console.log("Null move was found!");
			return false;
		}
		if(this.winner) return false;
		for(let r=0;r<this.rows;r++){
			const currentKey=JSON.stringify([column,r]);
			if(this.tokens.get(currentKey)===null&&this.getPossibleMoves().has(column)){
				let newToken=new Token(this.getTurn(),this,this.isVirtual);
				this.tokens.set(currentKey,newToken);
				this.updateWinnablePositions();
				this.checkWin();
				this.moveSequence.push([currentKey,newToken]);
				if (!this.isVirtual) {
					// Call a more specific rendering function
					this.renderSingleToken(currentKey, newToken);
				}
				return newToken;
			}
		}
		//console.log("Bad move: "+column);
		return false;
	}
	updateValueMap(){
		Array.from(this.tokens).forEach((v,k)=>{
			if(!this.isVirtual){
				const [col,row]=JSON.parse(v[0]);
				const scoreP0=this.scoreSlot(0,col,row);
				const scoreP1=this.scoreSlot(1,col,row);
				const escS=encodeCssSelector(v[0]);
				const tElement=this.gameBoardElement.querySelector("#"+CSS.escape(escS));
				tElement.querySelector(".intersectionValuePlayer0").innerText=scoreP0;
				tElement.querySelector(".intersectionValuePlayer1").innerText=scoreP1;
			}
		});
	}
	renderSingleToken(key, token) {
		const escS = encodeCssSelector(key);
		const tElement = this.gameBoardElement.querySelector("#" + CSS.escape(escS));
		if (tElement && !tElement.contains(token.node)) {
			tElement.appendChild(token.node);
		}
		this.updateValueMap();
	}
	clear(){
		if(this.moveSequence.length>0){
			this.tokens.forEach((v,k)=>this.tokens.set(k,null));
			this.playerWinningPositions[0]=structuredClone(this.baseWinningPositions);
			this.playerWinningPositions[1]=structuredClone(this.baseWinningPositions);
			this.moveSequence=[];
			if(!this.isVirtual) this.gameBoardElement.querySelectorAll(".token").forEach((e)=>e.remove());
			this.resetWinState();
			this.updateValueMap();
			return true;
		}
		return false;
	}
	countTokens(){
		let tokenCount=0;
		for(const value of this.tokens.values())if(value!==null)tokenCount++;
		return tokenCount;
	}
	getPossibleMoves(){
		const returnSet=new Set();
		for (let c=0;c<this.columns;c++){
			const topPositionKey=JSON.stringify([c,this.rows-1]);
			if (this.tokens.get(topPositionKey)===null){
				returnSet.add(c);
			}
		}
		return returnSet;
	}
	/**
	 * Determines which player's turn it is based on the current token count.
	 * @returns {number} 0 for Player 0, 1 for Player 1.
	 */
	getTurn(){
		return this.countTokens()%2;
	}
	/**
	 * Helper method to check if a given 4-token combination is currently winnable by a specific player.
	 * A line is "winnable" if it's not blocked by an opponent's token.
	 * This version does NOT check for gravity/reachability of empty spots.
	 *
	 * @param {Array<Array<number>>>} combination An array of [c, r] coordinates for the 4 spots.
	 * @param {number} player The ID of the player (0 or 1) to check winnability for.
	 * @returns {boolean} True if the line is currently winnable by the specified player, false otherwise.
	 */
	_isLineCurrentlyWinnable(combination,player){
		const opponent=(player===0)?1:0;
		for(const[c,r]of combination){
			const key=JSON.stringify([c,r]);
			const tokenAtPos=this.tokens.get(key);
			if(tokenAtPos!==null&&tokenAtPos.player===opponent)
				return false;
		}
		return true;
	}
	_areArraysEqual(arr1,arr2){
		if(arr1.length!==arr2.length)return false;
		for(let i=0;i<arr1.length;i++){
			const line1=arr1[i];
			const line2=arr2[i];
			if(line1.length!==line2.length)return false;
			for(let j=0;j<line1.length;j++){
				const coord1=line1[j];
				const coord2=line2[j];
				if(coord1[0]!==coord2[0]||coord1[1]!==coord2[1])
					return false;
			}
		}
		return true;
	}
	clone(){
		//it is very important to be sure that no DOM elements are present in any objects created here.
		const clonedBoard=new Board(this.columns,this.rows,null,true);
		for(const [key,token] of this.tokens.entries())clonedBoard.tokens.set(key,token?new Token(token.player,clonedBoard,true):null);
		//clonedBoard.baseWinningPositions=structuredClone(this.baseWinningPositions);
		clonedBoard.playerWinningPositions={
			0:structuredClone(this.playerWinningPositions[0]),
			1:structuredClone(this.playerWinningPositions[1])
		};
		for(const [pos,node] of this.moveSequence){
			clonedBoard.moveSequence.push(pos);
		}
		return clonedBoard;
	}
	checkWin(){
		for(const line of this.baseWinningPositions){
			let count=[0,0];
			for(const[c,r]of line){
				const token=this.tokens.get(JSON.stringify([c,r]));
				if(token&&token.player===0)count[0]++;
				if(token&&token.player===1)count[1]++;
				if(count[0]===4){
					this.winner=0;
					this.winningLineCoordinates=line;
					return 0;
				}
				else if(count[1]===4){
					this.winner=1;
					this.winningLineCoordinates=line;
					return 1;
				}
			}
		}
		if(this.countTokens()===this.rows*this.columns)return -1;
		this.winningLineCoordinates=null;
		return null;
	}
	/**
	 * Generates all 69 theoretical 4-in-a-row lines (geometric patterns) for the board dimensions.
	 * This method is called to obtain the full set of patterns for filtering.
	 * @returns {Array<Array<Array<number>>>} A list of all possible winning line coordinate combinations.
	 */
	findWinningPositions(){
		const allLines=[];
		const columns=this.columns;
		const rows=this.rows;
		for(let r=0;r<rows;r++)
			for(let c=0;c<=columns-4;c++)
				allLines.push([[c,r],[c+1,r],[c+2,r],[c+3,r]]);
		for(let c=0;c<columns;c++)
			for(let r=0;r<=rows-4;r++)
				allLines.push([[c,r],[c,r+1],[c,r+2],[c,r+3]]);
		for(let c=0;c<=columns-4;c++)
			for(let r=0;r<=rows-4;r++)
				allLines.push([[c,r],[c+1,r+1],[c+2,r+2],[c+3,r+3]]);
		for(let c=0;c<=columns-4;c++)
			for(let r=3;r<rows;r++)
				allLines.push([[c,r],[c+1,r-1],[c+2,r-2],[c+3,r-3]]);
		return allLines;
	}
	updateWinnablePositions(){
		let changed=false;
		const newPlayer0Winnable=this.playerWinningPositions[0].filter(combination=>
			this._isLineCurrentlyWinnable(combination,0)
		);
		const newPlayer1Winnable=this.playerWinningPositions[1].filter(combination=>
			this._isLineCurrentlyWinnable(combination,1)
		);
		if(!this._areArraysEqual(this.playerWinningPositions[0],newPlayer0Winnable)){
			this.playerWinningPositions[0]=newPlayer0Winnable;
			changed=true;
		}
		if(!this._areArraysEqual(this.playerWinningPositions[1],newPlayer1Winnable)){
			this.playerWinningPositions[1]=newPlayer1Winnable;
			changed=true;
		}
		return changed;
	}
	countForks(player){
		let forkCount=0;
		const potentialForkSpots=new Map();
		const playerWinnableLines=this.playerWinningPositions[player];
		for(const line of playerWinnableLines){
			const emptySpotsInLine=line.filter(([col,row])=>{
				const key=`[${col},${row}]`;
				return this.tokens.get(key)===null;
			});
			if(emptySpotsInLine.length===1){
				const[col,row]=emptySpotsInLine[0];
				const key=`${col},${row}`;
				potentialForkSpots.set(key,(potentialForkSpots.get(key)||0)+1);
			}
		}
		for(const count of potentialForkSpots.values())if(count>=2)forkCount++;
		return forkCount;
	}
	
	
	/* START WORKING AREA */
	_getTokenCountInColumn(col){
		let count=0;
		for(let r=0;r<this.rows;r++){
			const key=JSON.stringify([col,r]);
			if(this.tokens.get(key)!==null){
				count++;
			}
		}
		return count;
	}
	_getEmptySlotsInColumnFromPoint(col,point){
		let count=0;
		for(let r=point;r>=0;r--){
			const key=JSON.stringify([col,r]);
			if(this.tokens.get(key)===null){
				count++;
			}
		}
		return count;
	}
	/*
	* Double threat is a winning position. A single threat is a potential Zugzwang
	* depending on whether or not findParityCountForColumn(threat_column) returns 1 or 0.
	* if it returns 0 it is not Zugzwang if it returns 1 it is Zugzwang. Theoretically, if
	* player can avoid playing into the threat col and block all opponents threats, the
	* opponent will eventually be forced to play into the threat, handing a win to player.
	* findZugzwang, attempts to locate winning lines in which player has at least three tokens
	* and in which _getEmptySlotsInColumnFromPoint(the_empty_column,the_empty_row) would return
	* a value greater than or equal to two. if this returned 1 then player should immediatly
	* play into the threat column as this a win. if this returns 2 or more then get findParityCountForColumn(threat_column)
	* will determine if this a winning position.
	*/
	findParityCountForColumn(col){
		let total=0;
		for(let i=0;i<this.columns;i++){
			if(i!==col){
				total+=this._getEmptySlotsInColumnFromPoint(i,this.rows-1);
			}
		}
		return total%2;
	}
    findZugzwang(player){
        // Filter for potential winning lines that contain exactly one empty slot.
		const threatLines=this.playerWinningPositions[player].filter(line=>{
			const emptyCount=line.filter(pos => this.tokens.get(JSON.stringify(pos))===null).length;
			return emptyCount===1;
		});
        const zugzwangThreats=new Set();
		const doubleZugzwangThreats=new Set();
		const simpleThreats=new Set();
		const tr=[];
        // Evaluate the empty slot in each identified threat line.
		for (const line of threatLines){
			const emptySlot=line.find(pos=>this.tokens.get(JSON.stringify(pos))===null);
			const col=emptySlot[0];
			const row=emptySlot[1];
			simpleThreats.add(col);
			const emptySlots=this._getEmptySlotsInColumnFromPoint(col,row);
			//push onto an array to compare it later. we are adding parity for conparison later.
			//we simply add this to a set afterward to force uniqueness.
			tr.push({column:col,parity:emptySlots%2});
			if(emptySlots>1){
				/*
				* Once we have identified a threat, we count the number of remaining moves everywhere else
				* and take its modulus and compare it to the parity of the modulus of the number of moves
				* that are need to play into this threat. From this we can determine if the opponent will be
				* forced to play into the winning move if all other remain moves are played out. Carefully
				* consider whether this should be !== or === keeping in mind that the heuristic evaluation is
				* excuted before the moves are simulated and passed in recursion for each recursion of minmax.
				*/
				if(this.findParityCountForColumn(col)!==emptySlots%2) zugzwangThreats.add(col);
			}
		}
		for(let i=0;i<tr.length;i++){
			/*
			* If this is size >1 then there are at least two unique threats.
			* There are threats on two different columns or opposite parity 
			* threats on the same column. This should be Zugzwang, a fork 
			* or Zugzwang into a fork.
			*/
			doubleZugzwangThreats.add(JSON.stringify(tr[i]));
		};
		const returnValue=new Set();
		// This is Zugzwang.
		if(zugzwangThreats.size > 0) returnValue.add("zugzwangThreat");
        // This is Zugzwang, a fork, or Zugzwang into a fork.
		if(doubleZugzwangThreats.size > 1) returnValue.add("doubleZugzwangThreat");
		//blockable forks have some value
		if(doubleZugzwangThreats.size===1) returnValue.add("blockableFork");
		//threatLines
		if(threatLines.length > 0) returnValue.add("simpleThreat");
		return returnValue;
	}
	/* END WORKING AREA */

	score(player,depth){
		const winner=this.checkWin();
		if(winner!==null){
			if(winner===-1) return 0;
			if(winner===player) return maxSafe;
			return minSafe;
		}
		let positionalScore=0;
		Array.from(this.tokens).forEach((v,k)=>{
			const [col,row]=JSON.parse(v[0]);
			//there are 268 total points on the board. It there is no legal positions that would grant this number.
			positionalScore+=this.scoreSlot(player,col,row);
		});
		// Get the result from findZugzwang
		const zugzwangResult=this.findZugzwang(player);
		let tacticalScore=0;
		/*
		* Some forks are preventable. These type of forks have miminal value.
		* They force the opponents move thereby reducing their options.
		* Simple threats, just like bloackable forks, reduce the opponents options.
		*/
		if(zugzwangResult.has("blockableFork")||zugzwangResult.has("simpleThreat")) positionalScore+=2; //This value should be set relative to the slot position scores
		/*
		* These are unstoppable threats. Should they be allowed to come about, they win the game.
		* They are given tactical score which always trumps positional score.
		* As a result it is vey important to only only include sharp guareenteed win tactics here.
		* Unblockable forks and Zugzwang. Because these positions are a forced win, they are given
		* equal weight.
		*/
		if(zugzwangResult.has("zugzwangThreat")||zugzwangResult.has("doubleZugzwangThreat")){
			if(zugzwangResult.has("doubleZugzwangThreats")&&depth<=searchDepth) console.log("Fork or Zugzwang into a fork found for player: "+player, this.tokens);
			if(zugzwangResult.has("zugzwangThreats")&&depth<=searchDepth) console.log("Zugzwang found for player: "+player, this.tokens);
			tacticalScore++;
		}
		const returnValue=tacticalScore*1000+positionalScore;
		return Number(returnValue);
	}
	scoreSlot(player,col,row){
		let totalScore=0;
		const playerWinnableLines=this.playerWinningPositions[player];
		for(const line of playerWinnableLines) if(line.some(pos=>pos[0]===col&&pos[1]===row)) totalScore++;
		return totalScore;
	}
	getWinningLineEndpoints(){
		if(this.winningLineCoordinates===null || this.isVirtual){
			return null;
		}

		// Helper to find a DOM element based on its coordinates
		const getElementFromCoords = (coords) => {
			const [c,r] = coords;
			// Assuming encodeCssSelector is available and formats correctly
			const key = JSON.stringify([c,r]);
			const escS = encodeCssSelector(key);
			return this.gameBoardElement.querySelector("#"+CSS.escape(escS));
		};

		const startCoords = this.winningLineCoordinates[0];
		const endCoords = this.winningLineCoordinates[3];

		const startElement = getElementFromCoords(startCoords);
		const endElement = getElementFromCoords(endCoords);

		if(startElement && endElement){
			return {startElement, endElement};
		}
		
		return null;
	}
}

// NOTE: You'll need to ensure the encodeCssSelector and buildNodeTree functions are defined and available in your code. The logic above assumes their existence based on your provided class.
export class Token{
	constructor(turn,parentObject,isVirtual=false){
		this.isVirtual=isVirtual;
		this.player=turn;
		this.parentObject=null;
		this.node=null;
		//it is very important to be sure that no DOM elements are present in the Token object unless !this.isVirtual
		if(!this.isVirtual){
			this.parentObject=parentObject;
			let tokenContainer=document.getElementById("tokenContainer");
			this.node=tokenContainer.querySelector(".baseToken").cloneNode(true);
			this.node.setAttribute("class", "falling-token token p"+turn);
			let fillElement=this.node.querySelector('[data-id="cm"]');
			fillElement.setAttribute("fill",playerColors[this.player]);
			fillElement.removeAttribute("data-id");
			this.node.getBoundingClientRect(); //force layout recalc for firefox
		}
	}
}
