/**
 * vim: et:ts=4:sw=4:sts=4
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPL-3.0-or-later)
 * Copyright 2025 Josh Y Oshiro
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
import{
	minSafe,
	maxSafe,
	positionalIncrement
} from "./globalDefinitions.js";

export class virtualBoard{
	constructor(columns,rows){
		this.rows=rows;
		this.columns=columns;
		this.cellCount=this.rows*this.columns;
		this.baseWinningPositions=this.findWinningPositions();
		this.board=[];
		this.winner=null;
		this.players=[0, 1];
		this.playerWinnableStatus=[new Array(this.baseWinningPositions.length).fill(true),new Array(this.baseWinningPositions.length).fill(true)];
		this.moveOrder=[[],[]];
		this.positionToWinningLines=this.findPositionToWinningLines();
		const zobristData=virtualBoard.getZobristData(this.columns,this.rows);
		this.zobristTable=zobristData.table;
		this.hash=0n;
		this.initializeBoard();
		this.columnHeights=new Array(this.columns).fill(0);
		this.lastMoveIndex=null;
		this.nextTurn=0;
		this.tokenCount=0;
	}
	static getZobristData(columns,rows){
		const cacheKey=`${columns}x${rows}`;
		if(!virtualBoard.zobristCache.has(cacheKey)){
			const cellCount=columns*rows;
			const table=[new Array(cellCount),new Array(cellCount)];
			let state=0x9E3779B97F4A7C15n^BigInt((columns<<8)|rows);
			const mask=(1n<<64n)-1n;
			const nextRandom=()=>{
				state=(state+0x9E3779B97F4A7C15n)&mask;
				let z=state;
				z=(z^(z>>30n))*0xBF58476D1CE4E5B9n&mask;
				z=(z^(z>>27n))*0x94D049BB133111EBn&mask;
				return z^(z>>31n);
			};
			for(let player=0;player<2;player++){
				for(let index=0;index<cellCount;index++){
					table[player][index]=nextRandom();
				}
			}
			virtualBoard.zobristCache.set(cacheKey,{table});
		}
		return virtualBoard.zobristCache.get(cacheKey);
	}
	_to1D(col, row){
		return row*this.columns+col;
	}

	_to2D(index){
		if(!Number.isInteger(index)) return null;
		const row=Math.floor(index/this.columns);
		const col=index%this.columns;
		return [col,row];
	}

	initializeBoard() {
		this.board = new Array(this.cellCount).fill(null);
	}
	findPositionToWinningLines(){
		const map=Array.from({length:this.cellCount},()=>[]);
		for(let i=0;i<this.baseWinningPositions.length;i++){
			for(const pos1d of this.baseWinningPositions[i]){
				map[pos1d].push(i);
			}
		}
		return map;
	}
	getPossibleMoves() {
		const returnSet = new Set();
		for (let col = 0; col < this.columns; col++) {
			if (this.columnHeights[col] < this.rows) {
				returnSet.add(col);
			}
		}
		return returnSet;
	}
	_applyStatusForIndex(index, player){
		const affectedPlayer=1-player;
		const winningLineIndices=this.positionToWinningLines[index];
		const statusChanges=[];
		for (const lineIndex of winningLineIndices){
			const previousValue=this.playerWinnableStatus[affectedPlayer][lineIndex];
			if(previousValue!==false){
				statusChanges.push({player:affectedPlayer,lineIndex,previousValue});
				this.playerWinnableStatus[affectedPlayer][lineIndex]=false;
			}
		}
		return statusChanges;
	}
	_checkWinFromIndex(index){
		if(this.tokenCount<7) return null;
		if(index===null||index===undefined) return null;
		const tokenOwner=this.board[index];
		if(tokenOwner===null||tokenOwner===undefined) return null;
		const winningLineIndices=this.positionToWinningLines[index];
		for (const lineIndex of winningLineIndices){
			const line=this.baseWinningPositions[lineIndex];
			const isWin=line.every(cellIndex=>this.board[cellIndex]===tokenOwner);
			if(isWin){
				this.winner=tokenOwner;
				return tokenOwner;
			}
		}
		if(this.tokenCount===this.rows*this.columns){
			this.winner=-1;
			return -1;
		}
		return null;
	}
	_placeMove(column, player){
		if(!Number.isInteger(column)) return null;
		const row=this.columnHeights[column];
		if(row<0||row>=this.rows) return null;
		const index=this._to1D(column,row);
		if(this.board[index]!==null) return null;
		this.board[index]=player;
		this.hash^=this.zobristTable[player][index];
		this.moveOrder[player].push(index);
		this.columnHeights[column]++;
		this.tokenCount++;
		this.lastMoveIndex=index;
		const statusChanges=this._applyStatusForIndex(index, player);
		this.winner=null;
		this._checkWinFromIndex(index);
		return {index,row,statusChanges};
	}
	makeMove(column){
		if(this.winner!==null) return false;
		const player=this.nextTurn;
		const placed=this._placeMove(column, player);
		if(placed===null) return false;
		this.nextTurn=1-player;
		return true;
	}
	applyMove(column){
		if(this.winner!==null) return null;
		const player=this.nextTurn;
		const undoRecord={
			column,
			player,
			previousWinner:this.winner,
			previousLastMoveIndex:this.lastMoveIndex,
			index:null,
			statusChanges:[]
		};
		const placed=this._placeMove(column, player);
		if(placed===null) return null;
		undoRecord.index=placed.index;
		undoRecord.statusChanges=placed.statusChanges;
		this.nextTurn=1-player;
		return undoRecord;
	}
	undoMove(undoRecord){
		if(undoRecord===null||undoRecord===undefined) return false;
		const {column,index,player,previousWinner,previousLastMoveIndex,statusChanges}=undoRecord;
		if(!Number.isInteger(index)||!Number.isInteger(column)) return false;
		if(this.moveOrder[player].at(-1)!==index) return false;
		if(this.board[index]!==player) return false;
		this.nextTurn=player;
		this.winner=previousWinner;
		this.lastMoveIndex=previousLastMoveIndex;
		this.tokenCount--;
		this.columnHeights[column]--;
		this.moveOrder[player].pop();
		this.hash^=this.zobristTable[player][index];
		this.board[index]=null;
		for(const {player:statusPlayer,lineIndex,previousValue} of statusChanges){
			this.playerWinnableStatus[statusPlayer][lineIndex]=previousValue;
		}
		return true;
	}
	isWinningMove(column, player=this.nextTurn){
		if(!Number.isInteger(column)||column<0||column>=this.columns) return false;
		const row=this.columnHeights[column];
		if(row<0||row>=this.rows) return false;
		const index=this._to1D(column,row);
		const winningLineIndices=this.positionToWinningLines[index];
		for(let idx=0;idx<winningLineIndices.length;idx++){
			const line=this.baseWinningPositions[winningLineIndices[idx]];
			let matches=0;
			for(let j=0;j<line.length;j++){
				const cellIndex=line[j];
				if(cellIndex===index){
					matches++;
					continue;
				}
				if(this.board[cellIndex]!==player){
					matches=-1;
					break;
				}
				matches++;
			}
			if(matches===4) return true;
		}
		return false;
	}
	getLastMove(){
		return this.lastMoveIndex;
	}
    _computeThreatFlags(player){
		let hasSingleParityThreat=false;
		let doubleParityCount=0;
		let immediateThreatCount=0;
		const parityPointKeys=[];
		const parityValues=[];
		for(let moveIdx=0;moveIdx<this.moveOrder[player].length;moveIdx++){
			const pos1d=this.moveOrder[player][moveIdx];
			if(this.board[pos1d]!==player) continue;
			const winningLineIndices=this.positionToWinningLines[pos1d];
			for(let idx=0;idx<winningLineIndices.length;idx++){
				const lineIndex=winningLineIndices[idx];
				if(!this.playerWinnableStatus[player][lineIndex]) continue;
				let playerCount=0;
				let emptyCount=0;
				let opponentCount=0;
				let emptyCol=-1;
				let emptyRow=-1;
				const line=this.baseWinningPositions[lineIndex];
				for(let j=0;j<4;j++){
					const cellIndex=line[j];
					const cell=this.board[cellIndex];
					if(cell===null){
						emptyCount++;
						const [lineCol,lineRow]=this._to2D(cellIndex);
						emptyCol=lineCol;
						emptyRow=lineRow;
					}else if(cell===player){
						playerCount++;
					}else{
						opponentCount++;
					}
				}
				if(emptyCount!==1||playerCount!==3||opponentCount!==0) continue;
				const numberEmptyAtAndBelow=this.countEmptyAtAndBelow(emptyCol,emptyRow);
				if(numberEmptyAtAndBelow===1){
					immediateThreatCount++;
				}else if(numberEmptyAtAndBelow>1){
					// Match the original Board.findZugzwang() parity rule:
					// outsideParity !== (emptySlots % 2), which is equivalent to
					// totalParityToPoint(emptyCol, emptyRow) === 1.
					if(this.countTotalParityToPoint(emptyCol,emptyRow)===1) hasSingleParityThreat=true;
					let pairSeen=false;
					for(let k=0;k<parityPointKeys.length;k++){
						if(parityPointKeys[k]===`${emptyCol},${emptyRow}`){
							pairSeen=true;
							break;
						}
					}
					const parityValue=numberEmptyAtAndBelow%2;
					let valueSeen=false;
					for(let k=0;k<parityValues.length;k++){
						if(parityValues[k]===parityValue){
							valueSeen=true;
							break;
						}
					}
					if(!pairSeen && !valueSeen){
						parityPointKeys.push(`${emptyCol},${emptyRow}`);
						parityValues.push(parityValue);
						doubleParityCount++;
					}
				}
			}
		}
		return {
			hasImmediateThreat: immediateThreatCount===1,
			hasForkThreat: immediateThreatCount>1,
			hasSingleParityThreat,
			hasDoubleParityThreat: doubleParityCount>1
		};
	}
	score(player){
		const winner=this.checkWin();
		if (winner!==null){
			if (winner===-1) return 0;
			if (winner===player) return maxSafe;
			return minSafe;
		}
		let positionalScore=0;
		for(let moveIdx=0;moveIdx<this.moveOrder[player].length;moveIdx++){
			const pos1d=this.moveOrder[player][moveIdx];
			if(this.board[pos1d]!==player) continue;
			const winningLineIndices=this.positionToWinningLines[pos1d];
			for(let idx=0;idx<winningLineIndices.length;idx++){
				const lineIndex=winningLineIndices[idx];
				if(this.playerWinnableStatus[player][lineIndex]) positionalScore+=positionalIncrement;
			}
		}
		const threatsResult=this._computeThreatFlags(player);
		const forkScore=threatsResult.hasForkThreat?1:0;
		const tacticalScore=(threatsResult.hasSingleParityThreat||threatsResult.hasDoubleParityThreat)?1:0;
		const immediateThreatScore=threatsResult.hasImmediateThreat?1:0;
		let returnValue =
			((forkScore&0x1)<<18)|
			((tacticalScore&0x1)<<17)|
			((immediateThreatScore&0x1)<<16)|
			(Math.min(Math.abs(positionalScore),65535)&0xFFFF);
		return Number(returnValue);
	}
	checkWin(){
		if(Number.isInteger(this.winner)) return this.winner;
		if(this.tokenCount===this.rows*this.columns){
			this.winner=-1;
			return -1;
		}
		return this._checkWinFromIndex(this.lastMoveIndex);
	}
	findWinningPositions(){
		const allLines=[];
		const columns=this.columns;
		const rows=this.rows;
		for(let r=0;r<rows;r++){
			for(let c=0;c<=columns-4;c++){
				allLines.push([
					this._to1D(c,r),
					this._to1D(c+1,r),
					this._to1D(c+2,r),
					this._to1D(c+3,r)
				]);
			}
		}
		for(let c=0;c<columns;c++){
			for (let r=0;r<=rows-4;r++){
				allLines.push([
					this._to1D(c,r),
					this._to1D(c,r+1),
					this._to1D(c,r+2),
					this._to1D(c,r+3)
				]);
			}
		}
		for (let c=0;c<=columns-4;c++){
			for (let r=0;r<=rows-4;r++){
				allLines.push([
					this._to1D(c,r),
					this._to1D(c+1,r+1),
					this._to1D(c+2,r+2),
					this._to1D(c+3,r+3)
				]);
			}
		}
		for (let c=0;c<=columns-4;c++){
			for (let r=3;r<rows;r++){
				allLines.push([
					this._to1D(c,r),
					this._to1D(c+1,r-1),
					this._to1D(c+2,r-2),
					this._to1D(c+3,r-3)
				]);
			}
		}
		return allLines;
	}
	countEmptyAtAndBelow(col,point){
		let count=0;
		for (let row=point;row>=0;row--){
			const index=this._to1D(col,row);
			if (this.board[index]===null){
				count++;
			}
		}
		return count;
	}
	countTotalParityToPoint(col,point){
		let total=0;
		for (let i=0;i<this.columns;i++){
			if(i!==col) total+=this.countEmptyAtAndBelow(i,this.rows-1); //count empty positions on all columns except 'col'
		}
		total+=this.countEmptyAtAndBelow(col,point); //also count empty positions in 'col' from point.
		return total%2;
	}
	clear(){
		this.initializeBoard();
		this.playerWinnableStatus=[new Array(this.baseWinningPositions.length).fill(true), new Array(this.baseWinningPositions.length).fill(true)];
		this.moveOrder=[[],[]];
		this.columnHeights=new Array(this.columns).fill(0);
		this.lastMoveIndex=null;
		this.winner=null;
		this.nextTurn=0;
		this.tokenCount=0;
		this.hash=0n;
	}
}
virtualBoard.zobristCache=new Map();
